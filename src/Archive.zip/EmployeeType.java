package objectOrientedProgramming;

public enum EmployeeType {
FULLTIME,CONTRACTOR;
}
