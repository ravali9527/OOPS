package objectOrientedProgramming;
import java.util.*;

public class Contractor {
	private Date start;
	private Date end;
	private float hourlyRate;
	public Contractor(Date start, Date end, float hourlyRate) {
		this.start = start;
		this.end = end;
		this.hourlyRate = hourlyRate;
	}
	

}

	


