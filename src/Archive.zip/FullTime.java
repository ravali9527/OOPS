package objectOrientedProgramming;

import java.util.Date;

public class FullTime {

public FullTime(Date start, float baseSalaryPerYear, float bonusPerYear) {
		super();
		this.start = start;
		this.baseSalaryPerYear = baseSalaryPerYear;
		this.bonusPerYear = bonusPerYear;
	}
private Date start;
private float baseSalaryPerYear;
private float bonusPerYear;
	

}
