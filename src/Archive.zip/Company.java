package objectOrientedProgramming;

import java.util.List;

public class Company {
	private int id;
	private String name;
	private List<Employee>employeelist;
	
	public Company(int id, String name, List<Employee> employeelist) {
		this.id = id;
		this.name = name;
		this.employeelist = employeelist;
	
	
	
	}

}
